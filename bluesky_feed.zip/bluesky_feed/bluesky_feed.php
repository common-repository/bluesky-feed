<?php
/**
* Plugin Name: BlueskyFeed Widget
* Plugin URI: http://bs.bluesky.cn
* Description: 中文RSS订阅集合按钮，用于侧栏Widget。使用方法：外观》小工具》拖放到侧栏
* Version: 1.0
* Author: Bluesky Studio
* Author URI: http://bs.bluesky.cn
*/


if ( !defined('WP_CONTENT_URL') ) 
    define( 'WP_CONTENT_URL', get_option('siteurl') . '/wp-content'); 
if ( !defined('WP_CONTENT_DIR') ) 
    define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' ); 
// Guess the location 
$blueskyfeed_plugin_path = WP_CONTENT_DIR.'/plugins/'.plugin_basename(dirname(__FILE__)); 
$blueskyfeed_plugin_url = WP_CONTENT_URL.'/plugins/'.plugin_basename(dirname(__FILE__)); 

add_action( 'widgets_init', 'blueskyfeed_load_widgets' );

function blueskyfeed_load_widgets() {
	register_widget( 'blueskyfeed_widget' );
}

class blueskyfeed_widget extends WP_Widget {

	/**
	 * Widget setup.
	 */
	function blueskyfeed_widget() { 
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'blueskyfeed', 'description' => __('blueskyfeed: 中文RSS订阅集合按钮Widget.', 'blueskyfeed') );

		/* Widget control settings. */
		$control_ops = array( 'id_base' => 'blueskyfeed-widget' );

		/* Create the widget. */
		$this->WP_Widget( 'blueskyfeed-widget', __('blueskyfeed订阅按钮', 'blueskyfeed'), $widget_ops, $control_ops );
	}

	/**
	 * display the widget
	 */
	function widget( $args, $instance ) {
		extract( $args ); 

		$title = apply_filters('widget_title', $instance['title'] );
		$blueskyfeed_url = isset( $instance['blueskyfeed_url'] ) ? $instance['blueskyfeed_url'] : get_bloginfo_rss('rss2_url');
		$blueskyfeed_img = $instance['blueskyfeed_img'];
		if ($blueskyfeed_img!='') $blueskyfeed_img = '<img src="'. $blueskyfeed_img .'" alt="" align="absmiddle" />';
		$blueskyfeed_event = isset( $instance['blueskyfeed_event'] ) ? $instance['blueskyfeed_event'] : "mouseover";

		/* Before widget (defined by themes). */
		echo $before_widget;

		/* Display the widget title if one was input (before and after defined by themes). */
		if ( $title )
			echo $before_title . $title . $after_title;

		/* Display widget content. */
		echo '<span style="position:relative;z-index:999"><script type="text/javascript" src="http://bluesky-bookmark.googlecode.com/svn/trunk/feed.js" charset="UTF-8"></script><span style="position:relative;" class="feed_bluesky_cn"><a e="'. $blueskyfeed_event .'" href="'. $blueskyfeed_url .'" title="订阅我吧">'. $blueskyfeed_img .'</a></span></span>';

		/* After widget (defined by themes). */
		echo $after_widget;
	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['blueskyfeed_url'] = strip_tags( $new_instance['blueskyfeed_url'] );
		$instance['blueskyfeed_img'] = $new_instance['blueskyfeed_img'];
		$instance['blueskyfeed_img2'] = strip_tags( $new_instance['blueskyfeed_img2'] );
		if ($instance['blueskyfeed_img']=='manu' && $instance['blueskyfeed_img2']!='') $instance['blueskyfeed_img']=$instance['blueskyfeed_img2'];
		$instance['blueskyfeed_event'] = $new_instance['blueskyfeed_event'];

		return $instance;
	}

	/**
	 * Displays the widget settings controls on the widget panel.
	 */
	function form( $instance ) {
		global $blueskyfeed_plugin_url;
		/* Set up some default widget settings. */
		$defaults = array( 'title' => '', 'blueskyfeed_url' => get_bloginfo_rss('rss2_url'),'blueskyfeed_img' => $blueskyfeed_plugin_url."/f1.gif", 'blueskyfeed_img2' => "",'blueskyfeed_event' => 'mouseover' );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'hybrid'); ?>(选填)</label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'blueskyfeed_url' ); ?>"><?php _e('Feed Url:', 'blueskyfeed'); ?>(必须以http://等开头)</label>
			<input id="<?php echo $this->get_field_id( 'blueskyfeed_url' ); ?>" name="<?php echo $this->get_field_name( 'blueskyfeed_url' ); ?>" value="<?php echo $instance['blueskyfeed_url']; ?>" style="width:100%;" />
		</p>

		<p>
			<label><?php _e('图片样式:', 'blueskyfeed'); ?></label><br />
			<input name="<?php echo $this->get_field_name( 'blueskyfeed_img' ); ?>" type="radio" value="<?php echo $blueskyfeed_plugin_url; ?>/f1.gif"<?php if ($instance['blueskyfeed_img']==$blueskyfeed_plugin_url.'/f1.gif' || $instance['blueskyfeed_img']=='') echo ' checked="checked"'; ?> /><img src="<?php echo $blueskyfeed_plugin_url; ?>/f1.gif" alt="" /><br />
			<input name="<?php echo $this->get_field_name( 'blueskyfeed_img' ); ?>" type="radio" value="<?php echo $blueskyfeed_plugin_url; ?>/f2.gif"<?php if ($instance['blueskyfeed_img']==$blueskyfeed_plugin_url.'/f2.gif') echo ' checked="checked"'; ?> /><img src="<?php echo $blueskyfeed_plugin_url; ?>/f2.gif" alt="" /><br />
			<input name="<?php echo $this->get_field_name( 'blueskyfeed_img' ); ?>" type="radio" value="<?php echo $blueskyfeed_plugin_url; ?>/f4.gif"<?php if ($instance['blueskyfeed_img']==$blueskyfeed_plugin_url.'/f4.gif') echo ' checked="checked"'; ?> /><img src="<?php echo $blueskyfeed_plugin_url; ?>/f4.gif" alt="" />&nbsp; 
			<input name="<?php echo $this->get_field_name( 'blueskyfeed_img' ); ?>" type="radio" value="<?php echo $blueskyfeed_plugin_url; ?>/f5.gif"<?php if ($instance['blueskyfeed_img']==$blueskyfeed_plugin_url.'/f5.gif') echo ' checked="checked"'; ?> /><img src="<?php echo $blueskyfeed_plugin_url; ?>/f5.gif" alt="" /><br />
			<input name="<?php echo $this->get_field_name( 'blueskyfeed_img' ); ?>" type="radio" value="manu"<?php if ($instance['blueskyfeed_img']=='manu') echo ' checked="checked"'; ?> />自定义图片:<br />
			<input id="<?php echo $this->get_field_id( 'blueskyfeed_img2' ); ?>" name="<?php echo $this->get_field_name( 'blueskyfeed_img2' ); ?>" value="<?php echo $instance['blueskyfeed_img2']; ?>" style="width:100%;" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'blueskyfeed_event' ); ?>"><?php _e('触发事件类型:', 'blueskyfeed'); ?></label> 
			<select id="<?php echo $this->get_field_id( 'blueskyfeed_event' ); ?>" name="<?php echo $this->get_field_name( 'blueskyfeed_event' ); ?>" class="widefat" style="width:100%;">
				<option <?php if ( 'mouseover' == $instance['blueskyfeed_event'] ) echo 'selected="selected"'; ?>>mouseover(鼠标移动到图标上)</option>
				<option <?php if ( 'click' == $instance['blueskyfeed_event'] ) echo 'selected="selected"'; ?>>click(鼠标点击)</option>
			</select>
		</p>


	<?php
	}
}

?>
